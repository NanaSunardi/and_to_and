package com.example.latihanandtoand.di

import android.content.Context
import com.example.latihanandtoand.data.NewsRepository
import com.example.latihanandtoand.data.local.room.NewsDatabase
import com.example.latihanandtoand.data.remote.retrofit.ApiConfig

object Injection {
    fun provideRepository(context: Context): NewsRepository {
        val apiService = ApiConfig.getApiService()
        val database = NewsDatabase.getInstance(context)
        val dao = database.newsDao()
        return NewsRepository.getInstance(apiService, dao)
    }
}