package com.example.latihanandtoand.utils

import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

object DateFormatter {
    fun formatDate(currentDateString: String, targetTimeZone: String): String {
        val instant = Instant.parse(currentDateString)
        val formatter = DateTimeFormatter.ofPattern("dd MMM yyyy | HH:mm")
//            .withZone(ZoneId.of(TimeZone.getDefault().id))  // Utk membuat timezone sesuai dengan lokasi kita
            .withZone(ZoneId.of(targetTimeZone))  // Disebut dependency injection: agar kode menjadi lebih mudah dites karena kita tidak tergantung pada hal yang di luar kendali kita
        return formatter.format(instant)
    }
}