package com.example.latihanandtoand.data

import com.example.latihanandtoand.data.remote.response.NewsResponse
import com.example.latihanandtoand.data.remote.retrofit.ApiService
import com.example.latihanandtoand.utils.DataDummy

class FakeApiService : ApiService {

    private val dummyResponse = DataDummy.generateDummyNewsResponse()

    override suspend fun getNews(apiKey: String): NewsResponse {
        return dummyResponse
    }
}